
SECURESCAN PRO

Features:
1. Website Security Analysis
2. HTTPS Verification
3. Security Header Detection
4. Risk Level Classification
5. SQLite Database Scan History
6. Security Score Generator

Run:
pip install flask requests
python app.py
