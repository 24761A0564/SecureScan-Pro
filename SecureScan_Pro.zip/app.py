
from flask import Flask, render_template, request
import requests, sqlite3
from urllib.parse import urlparse
from datetime import datetime

app = Flask(__name__)

def init_db():
    conn=sqlite3.connect("scans.db")
    c=conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS scans(url TEXT, score INTEGER, scanned_at TEXT)")
    conn.commit()
    conn.close()

init_db()

def scan_site(url):
    if not url.startswith(("http://","https://")):
        url="https://"+url

    result={}
    r=requests.get(url,timeout=5)

    headers=r.headers
    sec_headers=[
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Strict-Transport-Security"
    ]

    score=0
    if url.startswith("https://"):
        score+=40

    found=[]
    for h in sec_headers:
        if h in headers:
            found.append(h)
            score+=15

    domain=urlparse(url).netloc

    conn=sqlite3.connect("scans.db")
    c=conn.cursor()
    c.execute("INSERT INTO scans VALUES(?,?,?)",
              (domain,score,datetime.now().strftime("%Y-%m-%d %H:%M")))
    conn.commit()
    conn.close()

    result["domain"]=domain
    result["score"]=min(score,100)
    result["headers"]=found

    risk="Low"
    if score<50: risk="High"
    elif score<80: risk="Medium"

    result["risk"]=risk
    return result

@app.route("/",methods=["GET","POST"])
def index():
    report=None
    if request.method=="POST":
        report=scan_site(request.form["url"])
    return render_template("index.html",report=report)

if __name__=="__main__":
    app.run(debug=True)
